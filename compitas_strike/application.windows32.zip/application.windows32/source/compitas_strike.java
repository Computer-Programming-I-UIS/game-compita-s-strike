import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import ddf.minim.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class compitas_strike extends PApplet {


Minim menu,tox,parc,cov,bols,ey;
AudioPlayer player1,bolsa,covi;
AudioSample toxic,eyc,parci;


PImage plaza,parcialito,fondomenu,libros,toxi,pegi,esrb,titulo,fondofeo;

boolean colision=false,covid=false,menu1=true,menu2=false, menu3=false,tutorial=false,creditos=false, juego=false,muertecov=false,muerteprom=false,plazct=false,plazche=false,i=false,oldi=false;
float vida=1250;
Personajes principal;
Personajes profe;

Tutorial pags;
toxi toxicombo;
int dif=2,r1=215,r2=215,r3=215,r4=215,g1=166,g2=166,g3=166,g4=166,tempo=0;
public void setup(){
  
  
  menu= new Minim(this);
  tox = new Minim (this);
  ey= new Minim(this);
  bols = new Minim(this);
  parc = new Minim(this);
  cov= new Minim(this);
  player1 = menu.loadFile("menu.wav",1024);
  toxic = tox.loadSample("toxi.mp3",2000);
  eyc = ey.loadSample("cuidadito.mp3",1024);
  bolsa = bols.loadFile("bolsa.mp3",1024);
  covi = cov.loadFile("covid.mp3",1024);
  parci = parc.loadSample("parcial.mp3",1024);
  principal= new Personajes (width/2,height/2,13,460,34,50);  
  profe= new Personajes(width,PApplet.parseInt(random(0,height)),1,259,29,42);
  pags= new Tutorial(0,1,false,false);
  toxicombo = new toxi();
  
 
}
public void draw(){

   tempo-=1/frameRate;
   if(tempo==0){
    player1.rewind();  
    tempo=1000;}
  println(tempo);
  if (menu1==true){
  
  player1.play();
      
      menu1();
    }
  else if(menu3==true){
    menu3();
    
  }
  else if(menu2==true){ 
  player1.play();
      
   menu2();
  }
  else if (tutorial==true){
  player1.pause();
 
  pags.paginas();
    
 }
  
  else if(juego==true){
  parci.shiftGain(parci.getGain(),+100,1024);  
  player1.shiftGain(player1.getGain(),-10,1024);
  eyc.shiftGain(eyc.getGain(),-10,1024); 
   parcialito= loadImage("parcial.png");
  if(plazche==true){
   image(plaza,0,0);}
  else{
    image(fondofeo,0,0);}
   fill(255,191,0);
   rect(0,0,width,100);
   copy(parcialito,9,4,19,20,width/2+70,20,30,30);
   timer();
    
    toxicombo.display();
    profe.moveProfes();
    profe.display();
    principal.movePerso();
    principal.display();
    principal.colision();
    barraestudio();
    barras(); 
     promedio();
   if(toxicombo.comer()==true){
    toxicombo = new toxi();
    if(vida<=1210){
    vida+=40;
    toxic.trigger();}
    else{
    vida+=1250-vida;
  toxic.trigger();}
    }
  }
  else if(creditos==true){
    player1.pause();
  creditos();
  }
 
    
  
}
/**************FUNCIONES PARA BUEN FUNCIONAMIENTO DE LAS TECLAS************/
public void keyPressed(){
  if(key==CODED)principal.keycontrol(keyCode, true);
  if(key!=CODED)pags.controls(key,true);
  if(key!=CODED)volvera(key,true);
  
   
}
public void keyReleased(){
 if(key==CODED)principal.keycontrol(keyCode, false);
 if(key!=CODED)pags.controls(key,false);
 if(key!=CODED)volvera(key,false);
}

/**********TODO LO RELACIONADO A LA BARRA DE VIDA Y MUERTE POR COVID***********/
public void barras(){
  noFill();
  stroke(0,250,0);
  strokeWeight(5);
  rectMode(CORNERS);
  rect(900,20,1250,60);
  stroke(0);
  strokeWeight(0);
  fill(0);
  noStroke();
  rect(900,20,vida,60);
  textSize(15);
  text("SALUD",920,85);
  if(covid==true && vida!=900){
  vida-=dif;
  }
  if(vida==900&&muerteprom==false)
  {
    principal.velocidadperso=0;
     profe.velocidadprof=0;
     muertecov=true;
     background(0);
     fill(255,0,0);
     textSize(50);
     time=10000;
     eyc.stop();
     
      covi.shiftGain(covi.getGain(),+200,1024);
      player1.pause();
  

   covi.play();
   
     
     text("TIENES COVID",(width/2)-150,height/2);
     text("Sobreviviste a:",(width/2-250),height/2+70);
     text(parciales,width/2+100,height/2+70);
     text("parciales", width/2+160,height/2+70);
     textSize(30);
     fill(0,0,255);
     text("presiona alguna letra para volver al menú",(width/2)-70,height-30);
     if(keyPressed==true&&key!=CODED){
    menu2=true;
    juego=false;
    prom=5;
    nota=5;
    estudio=100;
    time=round(random(700,800));
    
  principal.x=width/2;
  principal.y=height/2;
  profe.x=width;
  profe.y=PApplet.parseInt(random(0,height));}
  
}
  
}
/*************SELECCIÓN DIFICULTAD************************/
public void menu2(){
  cursor(ARROW);
  covi.rewind();
  covi.pause();
  bolsa.rewind();
  bolsa.pause();
  parciales=0;
  principal.x=width/2;
  principal.y=height/2;
  profe.x=width;
  profe.y=PApplet.parseInt(random(0,height));;
  muertecov=false;
  muerteprom=false;
  background(0);
  textSize(50);
  fill(255);
  text("Elige la dificultad",width/2-200,150);
  text("1.Facil",width/2-300,250);
  text("2.Medio",width/2-300,300);
  text("3.Mastodonte",width/2-300,350);
  textSize(20);
  text("elige con el teclado numerico", (width/2)-60, 400);
  textSize(20);
    text("Presiona s para volver a selección de escenario",width-500,height-50);
  if(keyPressed==true){
      if(key=='1'){
        menu2=false;
        vida=1250;
       profe.velocidadprof=4;
       principal.velocidadperso=10;
       juego=true; 
    }                                                    
      else if(key=='2'){
      menu2=false;
      profe.velocidadprof=5;
      vida=1250;
      principal.velocidadperso=10;
      juego=true; 
      
    }
      else if(key=='3'){
        menu2=false;
        profe.velocidadprof=7;
        vida=1250;
        principal.velocidadperso=10;
        juego=true; 
        
    }
    if(i==true&&oldi==false){ 
      menu3=true;
      menu2=false;
      }
     oldi=i;
   } 
   
}

/******************************MENÚ PRINCIPAL********************************************/
public void menu1(){
  fondomenu=loadImage("fondo-menu.jpeg");
  image(fondomenu,0,0);
  rectMode(CORNER);
  stroke(0);
  fill(r1,g1,0);
  rect(440,300,400,50);
  fill(r2,g2,0);
  rect(440,370,400,50);
  fill(r3,g3,0);
  rect(440,440,400,50);
  fill(r4,g4,0);
  rect(440, 510,400,50);
  if(mouseX>440&&mouseX<840&&mouseY>300&&mouseY<350){
    r1=167;
    g1=129;
    r2=215;
    g2=166;
    r3=215;
    g3=166;
    r4=215;
    g4=166;
    cursor(HAND);
    if(mousePressed){
    menu1=false;
    menu3=true;}
    }
   else if(mouseX>440&&mouseX<840&&mouseY>370&&mouseY<420){
    r2=167;
    g2=129;
    r1=215;
    g1=166;
    r3=215;
    g3=166;
    r4=215;
    g4=166;
    cursor(HAND);
    if(mousePressed){
    menu1=false;
    tutorial=true;
    }}
   else if(mouseX>440&&mouseX<840&&mouseY>440&&mouseY<490){
    r1=215;
    g1=166;
    r2=215;
    g2=166;
    r3=167;
    g3=129;
    r4=215;
    g4=166;
    
    cursor(HAND);
    if(mousePressed){
    menu1=false;
    creditos=true;}}
   else if(mouseX>440&&mouseX<840&&mouseY>510&&mouseY<560){
    r1=215;
    g1=166;
    r2=215;
    g2=166;
    r3=215;
    g3=166;
    r4=167;
    g4=129;
    cursor(HAND);
  
    if(mousePressed){
    exit();}}
  else{
    r1=215;
    g1=166;
    r2=215;
    g2=166;
    r3=215;
    g3=166;
    r4=215;
    g4=166;
    cursor(ARROW);
  }

  titulo=loadImage("titulo2.png");
  
   textSize(30);
   fill(0);
   text("Nuevo Juego",width/2-100,335);
   text("Historia y tutorial",width/2-130,405);
   text("Créditos",width/2-70,475);
   text("Salir",width/2-40,545);
   pegi = loadImage("7.png");
   copy(pegi,0,0,424,518,20,height-140,100,140);
   esrb = loadImage("índice.png");
   copy(esrb,3,4,176,267,140,height-140,100,140);
   image(titulo,width/2-350,150);
}
/***************************SELECCIÓN DE ESCENARIO*******************************************/
public void menu3(){
  background(0);
    plaza= loadImage("plazache.png");
    fondofeo=loadImage("dibujo.png");
    textSize(60);
    fill(255);
    text("Selecciona el escenario",(width/2)-300,100 );
    textSize(20);
    text("Plazoleta ''Che''",width/2-450,height/2+150);
    text("Plazoleta Camilo Torres",width/2+250,height/2+150);
    image(plaza,width/2-550,height/2-100, 400,200);
    image(fondofeo,width/2+150,height/2-100, 400,200);
    if(mouseX>=width/2-550&&mouseX<=width/2-150&&mouseY>=height/2-100&&mouseY<=height/2+100){
    cursor(HAND);
      if(mousePressed){
        menu3=false;
        menu2=true;
        plazche=true;
        plazct=false;
    }}
    else if(mouseX>=width/2+150&&mouseX<=width/2+550&&mouseY>=height/2-100&&mouseY<=height/2+100){
    cursor(HAND);
      if(mousePressed){
        menu3=false;
        menu2=true;
        plazct=true;
        plazche=false;
    }}
    else{cursor(ARROW);}
    if(i==true&&oldi==false){ 
      menu1=true;
      menu3=false;
      }
     oldi=i;
     text("Presiona s para volver al menú principal",width-500,height-50);
  }
  public void volvera(int s, boolean j){
    if(s=='s'){i=j;}
    
  }
  
public void creditos(){  
  background(0);
  fill(255);
  textSize(50);
  text("Compitas Strike",width/2-120,70);
  textSize(30);
  text("Proyecto desarrollado por Rafael Santiago Suárez Gil y Daniel Augusto García",50,130);
  textSize(20);
  text("Los personajes utilizados son propiedad de la franquicia POKÉMON ",50,170);
  text("Las imágenes del menún principal y del escenario son representaciones de la Universidad Industrial de Santander UIS ",50,200);
  text("La imagen del menú principal fue tomada del server ''UISCRAFT'' de Minecraft",50,230);
  text("Las imágenes son utilizadas únicamente con fínes académicos, todos los derechos reservados a los respectivos autores",50,260);
  text("Banda sonora ''Adventure Meme'' compuesta por Kevin MacLeod, libre de copyright",50,290);
  text("Los efectos de sonido fueron tomados del sitio público sonidosmp3gratis.com y realizados por los desarrolladores",50,320);
  textSize(30);
  text("Agradecimientos especiales:",50,360);
  textSize(20);
  text("Profesor Camilo Eduardo Rojas Ortiz, Processing Foundation, Mojang Studios, Incompetech music y sonidosmp3gratis.com",50,390);
  textSize(20);
  text("Presione s para volver al menu principal",width-410,height-50);
  if(keyPressed){
  if(key=='s'){
     tutorial=false;
     menu1=true;}
   }
  
  
}
int time=round(random(700,800)),parciales=0;
float prom=5,estudio=100,nota=5; 


public void timer(){
  libros= loadImage("libros.png");
  copy(libros,2,28,436,394,150,570,150,150);
  time-=1/frameRate;
  if(time==0){
  prom=(prom+nota)/2;
  time=round(random(700,800));
  estudio=100;
  parciales++;
  }
  else if(time==80){
  parci.trigger();}
}
public void promedio(){
  
  textSize(50);
  fill(0);
  text(prom,width/2-155,60);
  text(parciales,width/2+110,60);
  textSize(15);
  text("PARCIALES",width/2+85,85);
  text("PROMEDIO",width/2-135,85);
  nota=map(estudio,100,450,0,5);
  if(prom<3&&muertecov==false){
    background(0);
    bolsa.shiftGain(bolsa.getGain(),+20,1024);
    player1.pause();
    bolsa.play();
  principal.velocidadperso=0;
     profe.velocidadprof=0;
     muerteprom=true;
     fill(255,0,0);
     textSize(50);
     text("ESTÁS BOLSA",(width/2)-150,height/2);
     text("Sobreviviste a:",(width/2-250),height/2+70);
     text(parciales-1,width/2+100,height/2+70);
     text("parciales", width/2+160,height/2+70);
     bolsa.play();
     eyc.stop();
     time=10000;
     textSize(30);
     fill(0,0,255);
     text("presiona alguna letra para volver al menú",(width/2)-70,height-30);
     if(keyPressed==true&&key!=CODED){
    menu2=true;
    juego=false;
    time=round(random(700,800));
    principal.x=width/2;
  principal.y=height/2;
  profe.x=width;
  profe.y=PApplet.parseInt(random(0,height));
    prom=5;
    nota=5;
    }
  }
}
public void barraestudio(){
  noFill();
  stroke(0,250,0);
  strokeWeight(5);
  rectMode(CORNERS);
  rect(100,20,450,60);
  stroke(0);
  strokeWeight(0);
  fill(0);
  noStroke();
  rect(100,20,estudio,60);
  textSize(15);
  text("ESTUDIO",120,85);
  if(principal.x>=150&&principal.x<=300 && principal.y<=720&&principal.y>=570 &&estudio<=444){
  estudio+=1.5f;}
  else if(principal.x>=150&&principal.x<=300 && principal.y<=720&&principal.y>=570 &&estudio>444&&estudio!=450){
  estudio++;}

  
}
class Personajes{
    int x,y, velocidadperso=10,velocidadprof=4,tiempo=0;
    boolean arriba, abajo, der, izq;
    int wx, wy, w, h;
    PImage prueba;
    float d;
   
    
    Personajes (int tempx, int tempy, int tempwx,int tempwy, int tempw, int temph){
   
    x=tempx;
    y=tempy;
    wx=tempwx;
    wy=tempwy;
    w=tempw;
    h=temph;
  }
   
   
  
    public void display(){
   prueba= loadImage("sprites.png");
    copy(prueba,wx,wy,w,h,x,y,w,h);
    
  }
  
    
    
   public void movePerso(){ 
    tiempo-=1/frameRate;
    if(tiempo==0){
    tiempo=7;} 
     
     if(arriba==true&&y>(95)){
       y-=velocidadperso;
       wy=652;
        if(tiempo==4){wx=77;}
    else if(tiempo==1){wx=207;}
      
     }
     else if (abajo==true&&y<height-h){
     y+=velocidadperso;
     wy=459;
   if(tiempo==4){wx=77;}
    else if(tiempo==1){wx=207;}
   }
   else if (der==true && x<width-w){
   x+=velocidadperso;
    wy=589;
    if(tiempo==4){wx=77;}
    else if(tiempo==1){wx=207;}
       }
   else if (izq==true&&x>w/2){
     x-=velocidadperso;
     wy=525;
  if(tiempo==4){wx=77;}
    else if(tiempo==1){wx=207;}
       }
   
    else{
    x+=0; y+=0;
    wx=13;
    }
  
  } 

    public void keycontrol(int k, boolean b){
   switch(k){
     case UP:
     arriba=b;
     
     break;
     case DOWN:
     abajo=b;
     
     break;
     case LEFT:
     izq=b;
     
     break;
     case RIGHT:
     der=b;
     
     break;}
  }
  public void moveProfes(){
    tiempo-=1/frameRate;
  if(tiempo==0){
  tiempo=7;} 
    if(colision==false){
    
   if(tiempo==4){wx=32;}
    else if(tiempo==1){wx=98;}
    if (x<principal.x-(velocidadprof-1)&&y>principal.y+(velocidadprof-1)){
    x+=velocidadprof;
    y-=velocidadprof;
    wy=405;
   
       
    
  }
    else if (x>principal.x+(velocidadprof-1)&&y>principal.y+(velocidadprof-1)){
    x-=velocidadprof;
    y-=velocidadprof;
    wy=405;
    
 
  }
    else if (x<principal.x-(velocidadprof-1)&&y<principal.y-(velocidadprof-1)){
    x+=velocidadprof;
    y+=velocidadprof;
    wy=260;

  }
    else if (x>principal.x+(velocidadprof-1)&&y<principal.y-(velocidadprof-1)){
    x-=velocidadprof;
    y+=velocidadprof;
    wy=260;

  
  }
    else if (x>=principal.x-(velocidadprof-1)&&x<=principal.x+(velocidadprof-1)&&y<principal.y+(velocidadprof-1)){
    y+=velocidadprof;
    wy=260;
 
     
  }
    else if (x>=principal.x-(velocidadprof-1)&&x<=principal.x+(velocidadprof-1)&&y>principal.y-(velocidadprof-1)){
    y-=velocidadprof;
    wy=405;

  
    }
    else if (x<principal.x+(velocidadprof-1)&&y>=principal.y-(velocidadprof-1)&&y<=principal.y+(velocidadprof-1)){
    x+=velocidadprof;
    wy=356;

   
  }
    else if (x>principal.x+(velocidadprof-1)&&y>=principal.y-(velocidadprof-1)&&y<=principal.y+(velocidadprof-1)){
    x-=velocidadprof;
    wy=307;

  }
  
    
  }
  else{
    y+=0;
    x+=0;
    wx=1;
    }
}

  public void colision(){
    
     d= dist(profe.x+17,profe.y+23,principal.x+17,principal.y+23);
     if(d>90){colision=false;}
     else{colision=true;}
     //println(covid);
     if(d>100){covid=false;}
     else{covid=true;
      eyc.trigger();}
   
  }
}
class toxi{
  PVector posicion;
  toxi(){
    posicion = new PVector(random(principal.w/2,width-principal.w),random(95,height-principal.h));
    
  }
  public void display(){
    toxi= loadImage("toxi.png");
    copy(toxi,10,9,150,160,PApplet.parseInt(posicion.x),PApplet.parseInt(posicion.y),30,30);
  } 
  public boolean comer(){
    if(dist(principal.x+17,principal.y+23,PApplet.parseInt(posicion.x),PApplet.parseInt(posicion.y))<30){
    return true;
    }
    else{
      return false;
    }
  }
}
 
 class Tutorial{
   int estados,pagina;
   boolean olds,i;
   
 Tutorial(int tempestados, int tempagina, boolean tempolds, boolean tempi){
 
   estados=tempestados;
   pagina=tempagina;
   olds=tempolds;
   i=tempi;
 }
 public void paginas(){
   principal.velocidadperso=10;
   profe.wy=259;
   profe.wx=1;
   
    if(i==true&&olds==false){
      pagina++; 
    }
    olds=i;
    switch (pagina){
    case 1:
     background(0);
     textSize(40);
     fill(255);
     text("Bienvenido de nuevo a la universidad compa",width/2-410 ,height/2);
     text("¡espero que esté preparado para sobrevivir!",width/2-410,height/2+50);
     textSize(20);
     fill(255);
     text("Presione s para continuar",width-410,height-50);
     break;
    case 2: 
     background(0);
     textSize(40);
     text("Recuerde que seguimos en pandemia",width/2-410,height/2);
     text("¡No se le pegue a la gente! ¿oyó?",width/2-410,height/2+50);
     textSize(20);
     text("Presione s para continuar",width-410,height-50);
     break;
    case 3:
      background(0);
      textSize(40);
      text("Muevase usando las flechas",width/2-230,60);
      rect(100,70,40,40);
      rect(100,120,40,40);
      rect(50,120,40,40);
      rect(150,120,40,40);
      line(120,105,120,80);
      line(120,125,120,150);
      line(85,140,60,140);
      line(155,140,180,140);
      triangle(115,80,125,80,120,75);
      triangle(115,150,125,150,120,155);
      triangle(60,145,60,135,55,140);
      triangle(180,145,180,135,185,140);
      textSize(20);
     text("Presione s para continuar",width-410,height-50);
      principal.display();
      principal.movePerso();
      break;
     case 4:
      background(0);
      textSize(30);
      text("¡Mantengase alejado del profesor que va a intentar acercarsele!",width/2-400,70);
      text("si no se aleja su barra de salud va a disminuir",width/2-300,115);
      text("y si llega a 0 se va a contagiar de Covid-19",width/2-300,160);
      profe.display();
      profe.x=width/2;
      profe.y=height/2;
      textSize(20);
      text("Presione s para continuar",width-410,height-50);
     
     break;
    case 5:
      background(0);
      textSize(30);
      text("Para recuperar su salud puede comerse un toxicombo... ",width/2-400,70);
      text("Son muy efectivos para atacar cualquier virus",width/2-300,115);
     toxi= loadImage("toxi.png");
    copy(toxi,10,9,150,160,width/2-50,height/2-50,100,100);
    textSize(20);
     text("Presione s para continuar",width-410,height-50);
      break;
     case 6:
      background(0);
      textSize(30);
      text("Compa ¡recuerde que también tiene que estudiar!",width/2-400,70);
      text("Los líbros estarán disponibles en todo momento",width/2-400,115);
      text("estos le permitirán prepararse para el ataque silencioso y repentino de los parciales",width/2-600,160);
      text("¡OJO! solo sabrá que atacarán cuando oiga ''parcial inminente''" ,width/2-500,205);
      text("así que ¡mantengase preparado!",width/2-200,250);
      text("si no se prepara su promedio bajará",width/2-250,295);
      text("Si su promedio queda por debajo de 3 QUEDARÁ EN BOLSA",width/2-360,340); 
       libros= loadImage("libros.png");
      copy(libros,2,28,436,394,width/2-75,360,150,150);
      textSize(20);
      text("Presione s para volver al menu principal",width-410,height-50);
       break;
     default:
     setup();
     tutorial=false;
     menu1=true;
    }
 }
 public void controls (int s, boolean j){
   if(s=='s'){i=j;}
   }
 }
 
  public void settings() {  size(1280,720); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "compitas_strike" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
